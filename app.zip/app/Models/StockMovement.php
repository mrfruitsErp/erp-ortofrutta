<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StockMovement extends Model
{

    use HasFactory;

    protected $fillable = [

        'company_id',
        'product_id',
        'document_id',
        'type',
        'qty',
        'weight',
        'price',
        'movement_date'

    ];

}