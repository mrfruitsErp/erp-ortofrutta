<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{

    protected $fillable = [
        'supplier_id',
        'product_id',
        'kg',
        'price',
        'total',
        'date'
    ];

}