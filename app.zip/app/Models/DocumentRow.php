<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Product;

class DocumentRow extends Model
{

    protected $table = 'document_rows';

    protected $fillable = [
        'document_id',
        'product_id',
        'boxes',
        'kg_estimated',
        'price_per_kg',
        'total'
    ];


    public function product()
    {
        return $this->belongsTo(Product::class);
    }

}