<?php

namespace App\Http\Controllers;

use App\Models\StockMovement;

class StockMovementController extends Controller
{

public function index()
{

$movements = StockMovement::orderBy('created_at','desc')->get();

return view('movements.index', compact('movements'));

}

}