<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{

    public function index()
    {
        $products = Product::all();
        return view('products.index', compact('products'));
    }


    public function create()
    {
        return view('products.create');
    }


    public function store(Request $request)
    {

        $product = new Product();

        $product->name = $request->name;
        $product->category = $request->category;
        $product->avg_box_weight = 0;

        $product->save();

        return redirect('/products');

    }

}