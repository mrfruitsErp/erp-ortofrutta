<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Purchase;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\StockMovement;

class PurchaseController extends Controller
{

public function index()
{

$purchases = Purchase::with('product','supplier')
->orderBy('id','desc')
->get();

return view('purchases.index', compact('purchases'));

}


public function create()
{

$products = Product::all();
$suppliers = Supplier::all();

return view('purchases.create', compact('products','suppliers'));

}


public function store(Request $request)
{

$product = Product::find($request->product_id);

$kg = $request->kg;
$price = $request->price;

/* SALVA ACQUISTO */

$purchase = new Purchase();

$purchase->supplier_id = $request->supplier_id;
$purchase->product_id = $request->product_id;
$purchase->kg = $kg;
$purchase->price = $price;
$purchase->total = $kg * $price;
$purchase->date = $request->date;

$purchase->save();


if($product){

/* CARICO MAGAZZINO */

$product->stock = $product->stock + $kg;

/* AGGIORNA COSTO PRODOTTO */

$old_cost = $product->cost_price ?? 0;

if($old_cost == 0){

$new_cost = $price;

}else{

$new_cost = ($old_cost + $price) / 2;

}

$product->cost_price = $new_cost;

$product->save();


/* MOVIMENTO MAGAZZINO */

$movement = new StockMovement();

$movement->product_id = $product->id;
$movement->type = "IN";
$movement->qty = $kg;
$movement->movement_date = $request->date;

$movement->save();

}

return redirect('/purchases');

}

}