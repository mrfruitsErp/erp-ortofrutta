<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Document;
use App\Models\DocumentRow;
use App\Models\Client;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
class DashboardController extends Controller
{
    public function index()
    {
        $today = date('Y-m-d');
        $documents = Document::whereDate('date',$today)->get();
        $revenue = 0;
        $cost = 0;
        foreach($documents as $doc){
            $rows = DocumentRow::where('document_id',$doc->id)->get();
            foreach($rows as $row){
                $kg = $row->kg_real ?? $row->kg_estimated;
                $revenue += $row->total;
                $cost_price = $row->cost_price ?? 0;
                $cost += $kg * $cost_price;
            }
        }
        $margin = $revenue - $cost;
        $docs_count = $documents->count();
        $margin_percent = 0;
        if($revenue > 0){
            $margin_percent = ($margin / $revenue) * 100;
        }
        /*
        TOP CLIENTI
        */
        $top_clients = DocumentRow::join('documents','documents.id','=','document_rows.document_id')
        ->join('clients','clients.id','=','documents.client_id')
        ->selectRaw('clients.name as client,
        SUM(document_rows.total - (document_rows.cost_price * document_rows.kg_estimated)) as margin')
        ->groupBy('clients.name')
        ->orderByDesc('margin')
        ->limit(5)
        ->get();
        /*
        TOP PRODOTTI
        */
        $top_products = DocumentRow::join('products','products.id','=','document_rows.product_id')
        ->selectRaw('products.name as product,
        SUM(document_rows.total - (document_rows.cost_price * document_rows.kg_estimated)) as margin')
        ->groupBy('products.name')
        ->orderByDesc('margin')
        ->limit(5)
        ->get();
        /*
        PRODOTTI SOTTO SCORTA - disabilitato finché non aggiungi colonne stock/min_stock
        */
        $low_stock = collect();
        /*
        VENDITE ULTIMI MESI
        */
        $months = [];
        $sales = [];
        try {
            $sales_data = Document::select(
                DB::raw('MONTH(date) as month'),
                DB::raw('SUM(total) as total')
            )
            ->groupBy('month')
            ->orderBy('month')
            ->get();

            foreach($sales_data as $s){
                $months[] = $s->month;
                $sales[] = $s->total;
            }
        } catch(\Exception $e) {
            $months = [];
            $sales = [];
        }
        return view('dashboard_modern',[
            'revenue'        => $revenue,
            'cost'           => $cost,
            'margin'         => $margin,
            'margin_percent' => $margin_percent,
            'docs_count'     => $docs_count,
            'top_clients'    => $top_clients,
            'top_products'   => $top_products,
            'low_stock'      => $low_stock,
            'months'         => $months,
            'sales'          => $sales
        ]);
    }
}