<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Payment;

class PaymentController extends Controller
{

    public function store(Request $request)
    {

        Payment::create([
            'document_id' => $request->document_id,
            'amount' => $request->amount,
            'payment_date' => $request->payment_date,
            'method' => $request->method
        ]);

        return redirect()->back();

    }

}