<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Document;
use App\Models\Client;
use App\Models\Product;
use App\Models\DocumentRow;
use App\Models\Stock;
use App\Models\StockMovement;

class DocumentController extends Controller
{

    public function index()
    {
        $documents = Document::all();
        return view('documents.index', compact('documents'));
    }


    public function create()
    {
        $clients = Client::all();
        $products = Product::all();

        return view('documents.create', compact('clients','products'));
    }


    public function store(Request $request)
    {

        $year = date('Y');

        $last = Document::whereYear('date',$year)->orderBy('id','desc')->first();

        if($last){
            $last_number = intval(substr($last->number,-4));
            $new_number = $last_number + 1;
        }else{
            $new_number = 1;
        }

        $formatted = str_pad($new_number,4,'0',STR_PAD_LEFT);

        $document = new Document();

        // QUESTO RISOLVE L'ERRORE
        $document->type = "DDT";

        $document->number = "DDT-$year-$formatted";

        $document->date = date('Y-m-d');

        $document->client_id = $request->client_id ?? 1;

        $document->total = 0;

        $document->save();


        $force = $request->force_stock ?? 0;

        $total_document = 0;

        if($request->products){

            foreach($request->products as $index => $product_id){

                if(!$product_id){
                    continue;
                }

                $boxes = $request->qty[$index] ?? 0;
                $price = $request->price[$index] ?? 0;

                $product = Product::find($product_id);

                if(!$product){
                    continue;
                }

                $stock = Stock::where('product_id',$product_id)->first();

                if($stock){

                    if(!$force && $stock->quantity < $boxes){

                        return back()->with('error',
                        'Magazzino insufficiente per il prodotto: '.$product->name);

                    }

                    $stock->quantity = $stock->quantity - $boxes;
                    $stock->save();

                }

                $row = new DocumentRow();

                $row->document_id = $document->id;
                $row->product_id = $product_id;

                $row->boxes = $boxes;

                $row->kg_estimated = $boxes;

                $row->price_per_kg = $price;

                $row->total = $boxes * $price;

                $row->save();


                $movement = new StockMovement();

                $movement->product_id = $product_id;
                $movement->document_id = $document->id;
                $movement->type = "OUT";
                $movement->qty = $boxes;
                $movement->movement_date = date('Y-m-d');

                $movement->save();

                $total_document += $row->total;

            }

        }

        $document->total = $total_document;

        $document->save();

        return redirect('/documents');

    }



    public function show($id)
    {

        $document = Document::findOrFail($id);

        $rows = DocumentRow::where('document_id',$id)->get();

        return view('documents.show', compact('document','rows'));

    }

}