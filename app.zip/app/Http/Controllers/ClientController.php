<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Client;
use App\Models\Document;
use App\Models\DocumentRow;

class ClientController extends Controller
{

public function index()
{

$clients = Client::all();

return view('clients.index', compact('clients'));

}


public function create()
{

return view('clients.create');

}


public function store(Request $request)
{

$client = new Client();

$client->name = $request->name;
$client->vat = $request->vat;
$client->address = $request->address;
$client->city = $request->city;

$client->save();

return redirect('/clients');

}


public function show($id)
{

$client = Client::findOrFail($id);

$documents = Document::where('client_id',$id)->get();


/* FATTURATO */

$revenue = 0;

foreach($documents as $doc){

$revenue += $doc->total;

}


/* COSTO MERCE */

$rows = DocumentRow::join('documents','documents.id','=','document_rows.document_id')
->where('documents.client_id',$id)
->select('document_rows.*')
->get();

$cost = 0;

foreach($rows as $row){

$kg = $row->kg_real ?? $row->kg_estimated;

$cost += $kg * $row->cost_price;

}


/* MARGINE */

$margin = $revenue - $cost;

$margin_percent = 0;

if($revenue > 0){

$margin_percent = ($margin / $revenue) * 100;

}


return view('clients.show', compact(
'client',
'documents',
'revenue',
'cost',
'margin',
'margin_percent'
));

}


public function edit($id)
{

$client = Client::findOrFail($id);

return view('clients.edit', compact('client'));

}


public function update(Request $request, $id)
{

$client = Client::findOrFail($id);

$client->name = $request->name;
$client->vat = $request->vat;
$client->address = $request->address;
$client->city = $request->city;

$client->save();

return redirect('/clients');

}


public function destroy($id)
{

$client = Client::findOrFail($id);

$client->delete();

return redirect('/clients');

}


/* ==============================
REPORT CLIENTI CON MARGINI
============================== */

public function report()
{

$clients = Client::all();

$data = [];

foreach($clients as $client){

$documents = Document::where('client_id',$client->id)->get();

$revenue = 0;

foreach($documents as $doc){

$revenue += $doc->total;

}

$rows = DocumentRow::join('documents','documents.id','=','document_rows.document_id')
->where('documents.client_id',$client->id)
->select('document_rows.*')
->get();

$cost = 0;

foreach($rows as $row){

$kg = $row->kg_real ?? $row->kg_estimated;

$cost += $kg * $row->cost_price;

}

$margin = $revenue - $cost;

$percent = 0;

if($revenue > 0){

$percent = ($margin / $revenue) * 100;

}

$data[] = [

'name' => $client->name,
'revenue' => $revenue,
'cost' => $cost,
'margin' => $margin,
'margin_percent' => $percent

];

}


/* ORDINA PER MARGINE */

usort($data,function($a,$b){

return $b['margin'] <=> $a['margin'];

});


return view('reports.clients',['clients'=>$data]);

}

}