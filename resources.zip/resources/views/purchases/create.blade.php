<h1>Nuovo Acquisto Merce</h1>

<br>

<a href="/dashboard">
<button>Torna Dashboard</button>
</a>

<br><br>

<form method="POST" action="/purchases">

@csrf

<table border="1" cellpadding="10">

<tr>
<td>Fornitore</td>
<td>

<select name="supplier_id" required>

<option value="">Seleziona fornitore</option>

@foreach($suppliers as $supplier)

<option value="{{ $supplier->id }}">
{{ $supplier->company_name }}
</option>

@endforeach

</select>

</td>
</tr>

<tr>
<td>Prodotto</td>
<td>

<select name="product_id" required>

<option value="">Seleziona prodotto</option>

@foreach($products as $product)

<option value="{{ $product->id }}">
{{ $product->name }}
</option>

@endforeach

</select>

</td>
</tr>

<tr>
<td>KG acquistati</td>
<td>
<input type="number" step="0.01" name="kg" required>
</td>
</tr>

<tr>
<td>Prezzo €/kg</td>
<td>
<input type="number" step="0.01" name="price" required>
</td>
</tr>

<tr>
<td>Data</td>
<td>
<input type="date" name="date" required>
</td>
</tr>

</table>

<br>

<button type="submit">Salva Acquisto</button>

</form>