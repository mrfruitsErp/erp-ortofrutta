<h1>Acquisti</h1>

<br>

<a href="/purchases/create">Nuovo Acquisto</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Data</th>
<th>Fornitore</th>
<th>Prodotto</th>
<th>Kg</th>
<th>Costo Kg</th>
<th>Totale</th>
</tr>

@foreach($purchases as $p)

<tr>

<td>{{ $p->id }}</td>
<td>{{ $p->date }}</td>
<td>{{ $p->supplier->name ?? '' }}</td>
<td>{{ $p->product->name ?? '' }}</td>
<td>{{ $p->qty }}</td>
<td>€ {{ number_format($p->cost_per_kg,2,',','.') }}</td>
<td>€ {{ number_format($p->total,2,',','.') }}</td>

</tr>

@endforeach

</table>