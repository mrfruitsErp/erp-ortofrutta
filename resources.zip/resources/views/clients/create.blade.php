<h1>Nuovo Cliente</h1>

<form method="POST" action="{{ route('clients.store') }}">
    @csrf

    <label>Ragione Sociale</label><br>
    <input type="text" name="ragione_sociale" required><br><br>

    <label>Partita IVA</label><br>
    <input type="text" name="partita_iva"><br><br>

    <label>Indirizzo</label><br>
    <input type="text" name="indirizzo"><br><br>

    <label>Città</label><br>
    <input type="text" name="citta"><br><br>

    <label>Telefono</label><br>
    <input type="text" name="telefono"><br><br>

    <label>Email</label><br>
    <input type="email" name="email"><br><br>

    <label>Fido</label><br>
    <input type="number" step="0.01" name="fido" value="0"><br><br>

    <label>Giorni Pagamento</label><br>
    <input type="number" name="giorni_pagamento" value="30"><br><br>

    <label>Metodo Pagamento</label><br>
    <input type="text" name="metodo_pagamento" value="bonifico"><br><br>

    <button type="submit">Salva Cliente</button>
</form>