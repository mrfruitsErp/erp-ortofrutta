<h1>Scheda Cliente</h1>

<br>

<h2>Dati Cliente</h2>

<table border="1" cellpadding="10">

<tr>
<td><strong>Nome</strong></td>
<td>{{ $client->name }}</td>
</tr>

<tr>
<td><strong>P.IVA</strong></td>
<td>{{ $client->vat }}</td>
</tr>

<tr>
<td><strong>Indirizzo</strong></td>
<td>{{ $client->address }}</td>
</tr>

<tr>
<td><strong>Città</strong></td>
<td>{{ $client->city }}</td>
</tr>

</table>

<br><br>


<h2>Analisi Cliente</h2>

<table border="1" cellpadding="10">

<tr>
<td><strong>Fatturato totale</strong></td>
<td>€ {{ number_format($revenue,2,',','.') }}</td>
</tr>

<tr>
<td><strong>Costo merce</strong></td>
<td>€ {{ number_format($cost,2,',','.') }}</td>
</tr>

<tr>
<td><strong>Margine</strong></td>
<td>€ {{ number_format($margin,2,',','.') }}</td>
</tr>

<tr>
<td><strong>Margine %</strong></td>
<td>{{ number_format($margin_percent,2,',','.') }} %</td>
</tr>

</table>

<br><br>


<h2>Documenti Cliente</h2>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Tipo</th>
<th>Numero</th>
<th>Data</th>
<th>Totale</th>
<th>Apri</th>
</tr>

@foreach($documents as $doc)

<tr>

<td>{{ $doc->id }}</td>

<td>{{ $doc->type }}</td>

<td>{{ $doc->number }}</td>

<td>{{ $doc->date }}</td>

<td>€ {{ number_format($doc->total,2,',','.') }}</td>

<td>
<a href="/documents/{{ $doc->id }}">
Apri
</a>
</td>

</tr>

@endforeach

</table>

<br><br>

<a href="/clients">← Torna ai clienti</a>