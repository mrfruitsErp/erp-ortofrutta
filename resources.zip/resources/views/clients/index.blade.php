<h1>Elenco Clienti</h1>

<br>

<a href="/clients/create">
<button>Nuovo Cliente</button>
</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Nome</th>
<th>P.IVA</th>
<th>Indirizzo</th>
<th>Città</th>
<th>Scheda</th>
</tr>

@foreach($clients as $client)

<tr>

<td>{{ $client->id }}</td>

<td>{{ $client->name }}</td>

<td>{{ $client->vat_number }}</td>

<td>{{ $client->address }}</td>

<td>{{ $client->city }}</td>

<td>
<a href="/clients/{{ $client->id }}">
Apri
</a>
</td>

</tr>

@endforeach

</table>