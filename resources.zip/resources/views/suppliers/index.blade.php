<h1>Fornitori</h1>

<br>

<a href="/suppliers/create">
<button>Nuovo Fornitore</button>
</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Ragione Sociale</th>
<th>Città</th>
</tr>

@foreach($suppliers as $supplier)

<tr>

<td>{{ $supplier->id }}</td>

<td>{{ $supplier->company_name }}</td>

<td>{{ $supplier->city }}</td>

</tr>

@endforeach

</table>