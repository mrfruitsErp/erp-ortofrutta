<h1>Nuovo Fornitore</h1>

<form method="POST" action="/suppliers">

@csrf

<table>

<tr>
<td>Ragione Sociale</td>
<td><input type="text" name="company_name"></td>
</tr>

<tr>
<td>P.IVA</td>
<td><input type="text" name="vat_number"></td>
</tr>

<tr>
<td>Telefono</td>
<td><input type="text" name="phone"></td>
</tr>

<tr>
<td>Email</td>
<td><input type="text" name="email"></td>
</tr>

<tr>
<td>Città</td>
<td><input type="text" name="city"></td>
</tr>

</table>

<br>

<button type="submit">Salva Fornitore</button>

</form>