<h1>Carico Magazzino</h1>

<br>

<a href="/magazzino">
<button>Torna al Magazzino</button>
</a>

<br><br>

<form method="POST" action="/loads">

@csrf

<label>Prodotto</label>

<br><br>

<select name="product_id">

@foreach($products as $product)

<option value="{{ $product->id }}">
{{ $product->name }}
</option>

@endforeach

</select>

<br><br>

<label>Quantità KG</label>

<br><br>

<input type="number" step="0.01" name="qty" required>

<br><br>

<label>Prezzo costo €/kg</label>

<br><br>

<input type="number" step="0.01" name="cost_price" required>

<br><br>

<button type="submit">Carica Magazzino</button>

</form>