<h1>Magazzino</h1>

<br>

<a href="/carico-magazzino">
<button>Carico Magazzino</button>
</a>

<br><br>

<a href="/movimenti-magazzino">
<button>Movimenti Magazzino</button>
</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Prodotto</th>
<th>Stock</th>
<th>Costo Medio</th>
<th>Unità</th>
<th>Alert</th>
</tr>

@foreach($products as $product)

<tr>

<td>{{ $product->id }}</td>

<td>{{ $product->name }}</td>

<td>{{ number_format($product->stock,3) }}</td>

<td>{{ number_format($product->cost_price,2) }}</td>

<td>{{ $product->unit }}</td>

<td>

@if($product->stock <= $product->min_stock)

<span style="color:red;font-weight:bold">
⚠ STOCK BASSO
</span>

@endif

</td>

</tr>

@endforeach

</table>