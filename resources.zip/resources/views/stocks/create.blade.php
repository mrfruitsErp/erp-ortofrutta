<h1>Carico Merce Magazzino</h1>

<br>

<form method="POST" action="/stock">

@csrf

<label>Prodotto</label>

<br>

<select name="product_id">

@foreach($products as $product)

<option value="{{ $product->id }}">
{{ $product->name }}
</option>

@endforeach

</select>

<br><br>

<label>Quantità (kg / casse / pz)</label>

<br>

<input type="number" step="0.01" name="qty" required>

<br><br>

<button type="submit">

Carica Magazzino

</button>

</form>

<br>

<a href="/magazzino">Torna al Magazzino</a>