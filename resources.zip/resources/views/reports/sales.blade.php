<h1>Report Margini Prodotti</h1>

<br>

<a href="/dashboard">
<button>Dashboard</button>
</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>Prodotto</th>
<th>KG Venduti</th>
<th>Fatturato €</th>
<th>Costo €</th>
<th>Margine €</th>
</tr>

@foreach($rows as $row)

<tr>

<td>{{ $row->name }}</td>

<td>{{ number_format($row->kg_venduti,2,',','.') }}</td>

<td>{{ number_format($row->fatturato,2,',','.') }}</td>

<td>{{ number_format($row->costo,2,',','.') }}</td>

<td>{{ number_format($row->fatturato - $row->costo,2,',','.') }}</td>

</tr>

@endforeach

</table>