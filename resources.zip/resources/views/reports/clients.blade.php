<h1>Report Clienti</h1>

<br>

<table border="1" cellpadding="10">

<tr>
<th>Cliente</th>
<th>Fatturato</th>
<th>Costo</th>
<th>Margine</th>
<th>Margine %</th>
</tr>

@foreach($clients as $c)

<tr>

<td>{{ $c['name'] }}</td>

<td>€ {{ number_format($c['revenue'],2,',','.') }}</td>

<td>€ {{ number_format($c['cost'],2,',','.') }}</td>

<td>€ {{ number_format($c['margin'],2,',','.') }}</td>

<td>{{ number_format($c['margin_percent'],2,',','.') }} %</td>

</tr>

@endforeach

</table>

<br><br>

<a href="/">← Dashboard</a>