<h1>Report Prodotti</h1>

<br>

<table border="1" cellpadding="10">

<tr>
<th>Prodotto</th>
<th>Kg Venduti</th>
<th>Fatturato</th>
<th>Costo</th>
<th>Margine</th>
<th>Margine %</th>
</tr>

@foreach($products as $p)

<tr>

<td>{{ $p['name'] }}</td>

<td>{{ number_format($p['kg'],2,',','.') }}</td>

<td>€ {{ number_format($p['revenue'],2,',','.') }}</td>

<td>€ {{ number_format($p['cost'],2,',','.') }}</td>

<td>€ {{ number_format($p['margin'],2,',','.') }}</td>

<td>{{ number_format($p['percent'],2,',','.') }} %</td>

</tr>

@endforeach

</table>

<br><br>

<a href="/dashboard">
<button>Torna Dashboard</button>
</a>