<h2>Righe Documento</h2>

@if($rows->count() == 0)

<p>Nessun prodotto inserito nel documento.</p>

@else

<table border="1" cellpadding="10">

<tr>
<th>Prodotto</th>
<th>KG Stimati</th>
<th>KG Reali</th>
<th>Prezzo</th>
<th>Totale</th>
</tr>

@foreach($rows as $row)

<tr>

<td>{{ $row->product->name }}</td>

<td>{{ $row->kg_estimated }}</td>

<td>

<form method="POST" action="/save-real-weight">

@csrf

<input type="hidden" name="row_id" value="{{ $row->id }}">

<input type="number" step="0.01" name="kg_real" value="{{ $row->kg_real }}">

<button type="submit">Salva</button>

</form>

</td>

<td>{{ number_format($row->price_per_kg,2,',','.') }}</td>

<td>{{ number_format($row->total,2,',','.') }}</td>

</tr>

@endforeach

</table>

@endif