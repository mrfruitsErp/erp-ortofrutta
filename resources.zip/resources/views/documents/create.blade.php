@extends('layouts.app')

@section('content')

<h2>Nuovo Documento</h2>

<form method="POST" action="/documents">
@csrf

<table border="1" width="100%" cellpadding="5" id="docTable">

<tr>
<th>Prodotto</th>
<th>Casse</th>
<th>Kg stimati</th>
<th>Prezzo €/kg</th>
<th>Costo</th>
<th>Margine</th>
</tr>

<tbody id="rows">

<tr>

<td>
<select name="products[]" class="product">
<option value="">-- seleziona --</option>

@foreach($products as $product)

<option 
value="{{ $product->id }}"
data-weight="{{ $product->avg_box_weight }}"
data-cost="{{ $product->cost ?? 0 }}"
>

{{ $product->name }}

</option>

@endforeach

</select>
</td>


<td>
<input type="number" name="qty[]" class="boxes" value="0">
</td>


<td>
<input type="text" class="kg" readonly value="0">
</td>


<td>
<input type="number" step="0.01" name="price[]" class="price" value="0">
</td>


<td class="cost">0</td>

<td class="margin">0</td>

</tr>

</tbody>

</table>

<br>

<button type="button" onclick="addRow()">

+ Aggiungi Riga

</button>

<br><br>

<h3>

Totale Documento: € <span id="docTotal">0.00</span>

</h3>

<br>

<button type="submit">

Salva Documento

</button>

</form>



<script>

function updateRow(row){

let product = row.querySelector(".product")
let boxes = parseFloat(row.querySelector(".boxes").value) || 0
let price = parseFloat(row.querySelector(".price").value) || 0

let weight = parseFloat(product.selectedOptions[0]?.dataset.weight || 0)
let cost = parseFloat(product.selectedOptions[0]?.dataset.cost || 0)

let kg = boxes * weight

row.querySelector(".kg").value = kg.toFixed(2)

let sale = kg * price
let totalCost = kg * cost
let margin = sale - totalCost

row.querySelector(".cost").innerText = totalCost.toFixed(2)
row.querySelector(".margin").innerText = margin.toFixed(2)

updateTotal()

}



function updateTotal(){

let total = 0

document.querySelectorAll("#rows tr").forEach(row => {

let kg = parseFloat(row.querySelector(".kg").value) || 0
let price = parseFloat(row.querySelector(".price").value) || 0

total += kg * price

})

document.getElementById("docTotal").innerText = total.toFixed(2)

}



function attachEvents(row){

row.querySelector(".boxes").addEventListener("input", () => updateRow(row))
row.querySelector(".product").addEventListener("change", () => updateRow(row))
row.querySelector(".price").addEventListener("input", () => updateRow(row))

}



document.querySelectorAll("#rows tr").forEach(row => {

attachEvents(row)

})



function addRow(){

let table = document.getElementById("rows")

let newRow = table.rows[0].cloneNode(true)

newRow.querySelectorAll("input").forEach(i => i.value = 0)
newRow.querySelector(".kg").value = 0
newRow.querySelector(".cost").innerText = 0
newRow.querySelector(".margin").innerText = 0

table.appendChild(newRow)

attachEvents(newRow)

}

</script>

@endsection