<!DOCTYPE html>
<html>

<head>

<meta charset="utf-8">

<title>DDT</title>

<style>

body{
font-family: Arial;
}

table{
border-collapse: collapse;
width:100%;
}

table, th, td{
border:1px solid black;
}

th, td{
padding:6px;
text-align:left;
}

</style>

</head>

<body>

<h1>DDT {{ $document->number }}</h1>

<p>Data: {{ $document->date }}</p>

<h3>Cliente</h3>

<p>{{ $document->client->name }}</p>

<br>

<h3>

Totale Documento:
{{ $rows->sum('total') }}

</h3>

<table>

<tr>
<th>Prodotto</th>
<th>Quantità</th>
<th>Prezzo</th>
<th>Totale</th>
</tr>

@foreach($rows as $row)

<tr>

<td>{{ $row->product->name }}</td>

<td>{{ $row->boxes }} {{ $row->product->unit }}</td>

<td>{{ $row->price_per_kg }}</td>

<td>{{ $row->total }}</td>

</tr>

@endforeach

</table>

</body>

</html>