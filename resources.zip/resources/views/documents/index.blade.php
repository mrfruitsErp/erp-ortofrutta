<h1>Documenti</h1>

<a href="/documents/create">Nuovo Documento</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Tipo</th>
<th>Numero</th>
<th>Data</th>
</tr>

@foreach($documents as $document)

<tr>

<td>{{ $document->id }}</td>

<td>{{ $document->type }}</td>

<td>
<a href="/documents/{{ $document->id }}">
{{ $document->number }}
</a>
</td>

<td>{{ $document->date }}</td>

</tr>

@endforeach

</table>