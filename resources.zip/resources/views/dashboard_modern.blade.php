@extends('layouts.app')

@section('content')

<h1>Dashboard</h1>

<div class="cards">

<div class="card">
<h3>Fatturato</h3>
<h2>€ {{ number_format($revenue,2,',','.') }}</h2>
</div>

<div class="card">
<h3>Costo Merce</h3>
<h2>€ {{ number_format($cost,2,',','.') }}</h2>
</div>

<div class="card">
<h3>Margine</h3>
<h2>€ {{ number_format($margin,2,',','.') }}</h2>
</div>

<div class="card">
<h3>Prodotti sotto scorta</h3>
<h2>{{ count($low_stock) }}</h2>
</div>

</div>


<div class="section">

<h2>Vendite ultimi mesi</h2>

<canvas id="salesChart"></canvas>

</div>


<div class="section">

<h2>Prodotti sotto scorta</h2>

<table>

<tr>
<th>Prodotto</th>
<th>Stock</th>
<th>Min</th>
</tr>

@foreach($low_stock as $p)

<tr>

<td>{{ $p->name }}</td>
<td>{{ $p->stock }}</td>
<td>{{ $p->min_stock }}</td>

</tr>

@endforeach

</table>

</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

const ctx = document.getElementById('salesChart');

new Chart(ctx,{

type:'bar',

data:{
labels:{!! json_encode($months) !!},
datasets:[{
label:'Vendite €',
data:{!! json_encode($sales) !!},
backgroundColor:'#4c6ef5'
}]
},

options:{
responsive:true
}

});

</script>

@endsection