<h1>Movimenti Magazzino</h1>

<table border="1" cellpadding="6">

<tr>
<th>Data</th>
<th>Ora</th>
<th>Prodotto</th>
<th>Movimento</th>
<th>Quantità</th>
<th>Documento</th>
</tr>

@foreach($movements as $movement)

<tr>

<td>{{ $movement->created_at->format('Y-m-d') }}</td>

<td>{{ $movement->created_at->format('H:i') }}</td>

<td>{{ $movement->product->name }}</td>

<td>

@if($movement->type == 'OUT')
USCITA
@elseif($movement->type == 'IN')
CARICO
@else
{{ $movement->type }}
@endif

</td>

<td>{{ $movement->qty }} {{ $movement->product->unit }}</td>

<td>
@if($movement->document)
DDT {{ $movement->document->number }}
@endif
</td>

</tr>

@endforeach

</table>