@extends('layout')

@section('content')

<h1>Nuova Fattura</h1>

<form method="POST" action="/documents">

@csrf

Cliente

<select name="client_id">

@foreach($clients as $client)

<option value="{{ $client->id }}">
{{ $client->company_name }}
</option>

@endforeach

</select>

<br><br>

Numero

<input type="text" name="number">

<br><br>

Data

<input type="date" name="date">

<br><br>


<h2>Prodotti</h2>

<table border="1" cellpadding="10" id="products_table">

<tr>
<th>Prodotto</th>
<th>Quantità</th>
<th>Prezzo</th>
<th>Totale</th>
<th></th>
</tr>

</table>


<button type="button" onclick="addRow()">Aggiungi Riga</button>

<br><br>


<h3>Totale</h3>

Totale Imponibile

<input type="text" id="subtotal" readonly>

<br><br>

IVA 22%

<input type="text" id="iva" readonly>

<br><br>

Totale Documento

<input type="text" id="total" readonly>

<br><br>


<button type="submit">Salva Fattura</button>

</form>



<script>

let products = @json($products);



function addRow(){

let table = document.getElementById("products_table");

let row = table.insertRow();

row.innerHTML = `

<td>

<select name="products[]" class="product">

<option value="">--</option>

${products.map(p => `<option value="${p.id}" data-price="${p.price}">${p.name}</option>`).join("")}

</select>

</td>

<td>

<input type="number" name="qty[]" class="qty" value="1">

</td>

<td>

<input type="number" name="price[]" class="price">

</td>

<td>

<input type="text" class="row_total" readonly>

</td>

<td>

<button type="button" onclick="removeRow(this)">X</button>

</td>

`;

attachEvents();

}



function removeRow(btn){

btn.parentNode.parentNode.remove();

calculateTotals();

}



function attachEvents(){

document.querySelectorAll(".product").forEach(select => {

select.onchange = function(){

let price = this.options[this.selectedIndex].dataset.price;

this.parentNode.parentNode.querySelector(".price").value = price;

calculateTotals();

}

});



document.querySelectorAll(".qty,.price").forEach(input => {

input.onkeyup = calculateTotals;

input.onchange = calculateTotals;

});

}



function calculateTotals(){

let rows = document.querySelectorAll("#products_table tr");

let subtotal = 0;



rows.forEach(row => {

let qty = row.querySelector(".qty");

let price = row.querySelector(".price");

let total = row.querySelector(".row_total");



if(qty && price && total){

let q = parseFloat(qty.value) || 0;

let p = parseFloat(price.value) || 0;



let rowTotal = q * p;

total.value = rowTotal.toFixed(2);



subtotal += rowTotal;

}

});



let iva = subtotal * 0.22;

let total = subtotal + iva;



document.getElementById("subtotal").value = subtotal.toFixed(2);

document.getElementById("iva").value = iva.toFixed(2);

document.getElementById("total").value = total.toFixed(2);

}

</script>

@endsection