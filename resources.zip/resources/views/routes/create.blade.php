@extends('layouts.app')

@section('content')

<div class="container">

<h2>Nuovo Giro Consegna</h2>

<form method="POST" action="/routes">

@csrf

<div style="margin-bottom:20px">

<label>Nome Giro</label>

<br>

<input type="text" name="name" required>

</div>

<div style="margin-bottom:20px">

<label>Giorno</label>

<br>

<input type="text" name="day" placeholder="Lunedì / Martedì / ecc">

</div>

<button type="submit">
Salva Giro
</button>

</form>

</div>

@endsection