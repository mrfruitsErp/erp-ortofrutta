@extends('layouts.app')

@section('content')

<div class="container">

<h2>Giri consegna</h2>

<br>

<a href="{{ url('routes/create') }}">+ Nuovo Giro</a>

<br><br>

<table border="1" cellpadding="8">

<tr>
<th>ID</th>
<th>Nome Giro</th>
<th>Giorno</th>
<th>Picking</th>
</tr>

@foreach($routes as $route)

<tr>

<td>{{ $route->id }}</td>

<td>{{ $route->name }}</td>

<td>{{ $route->day }}</td>

<td>

<a href="{{ url('route-picking/'.$route->id) }}">
Apri Picking
</a>

</td>

</tr>

@endforeach

</table>

</div>

@endsection