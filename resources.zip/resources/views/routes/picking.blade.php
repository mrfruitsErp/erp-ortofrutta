@extends('layouts.app')

@section('content')

<div class="container">

<h2>Carico Camion</h2>

<hr>

<h3>Giro: {{ $route->name }}</h3>

<hr>

<h4>Clienti del giro</h4>

<ul>

@foreach($clients as $client)

<li>{{ $client->name }}</li>

@endforeach

</ul>

<hr>

<h4>Picking prodotti</h4>

<table border="1" cellpadding="6">

<tr>
<th>Prodotto</th>
<th>Casse Totali</th>
<th>Kg Stimati</th>
</tr>

@foreach($rows as $row)

<tr>

<td>{{ $row->product }}</td>

<td>{{ $row->boxes }}</td>

<td>{{ number_format($row->kg,2) }}</td>

</tr>

@endforeach

</table>

</div>

@endsection