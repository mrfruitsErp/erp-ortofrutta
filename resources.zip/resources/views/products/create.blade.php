<h1>Nuovo Prodotto</h1>

<form method="POST" action="/products">

@csrf

<br>

Nome prodotto

<br>

<input type="text" name="name">

<br><br>

Prezzo di vendita

<br>

<input type="number" name="price" step="0.01">

<br><br>

Prezzo di costo

<br>

<input type="number" name="cost_price" step="0.01">

<br><br>

Unità di misura

<br>

<select name="unit">

<option value="kg">Kg</option>
<option value="cassa">Cassa</option>
<option value="pz">Pezzi</option>

</select>

<br><br>

Stock iniziale (giacenza)

<br>

<input type="number" name="stock" step="0.01">

<br><br>

<button type="submit">

Salva prodotto

</button>

</form>