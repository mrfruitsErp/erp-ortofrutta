<h1>Prodotti</h1>

<br>

<a href="/products/create">
<button>Nuovo prodotto</button>
</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
<th>Nome</th>
<th>Costo</th>
<th>Prezzo</th>
<th>Margine Min %</th>
<th>Prezzo Min</th>
<th>Stock</th>
<th>Stato</th>
</tr>

@foreach($products as $product)

@php

$min_price = $product->cost_price + ($product->cost_price * $product->min_margin / 100);

@endphp

<tr>

<td>{{ $product->name }}</td>

<td>€ {{ number_format($product->cost_price,2,',','.') }}</td>

<td>€ {{ number_format($product->price,2,',','.') }}</td>

<td>{{ $product->min_margin }} %</td>

<td>

€ {{ number_format($min_price,2,',','.') }}

</td>

<td>{{ $product->stock }} {{ $product->unit }}</td>

<td>

@if($product->price < $min_price)

<span style="color:red">

⚠ Prezzo sotto margine

</span>

@else

<span style="color:green">

OK

</span>

@endif

</td>

</tr>

@endforeach

</table>