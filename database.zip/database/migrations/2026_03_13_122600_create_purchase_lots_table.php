<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{

    public function up()
    {

        Schema::create('purchase_lots', function (Blueprint $table) {

            $table->id();

            // collegamento all'acquisto
            $table->unsignedBigInteger('purchase_id');

            // prodotto
            $table->unsignedBigInteger('product_id');

            // kg acquistati
            $table->decimal('kg_total',10,2);

            // kg rimasti in magazzino
            $table->decimal('kg_remaining',10,2);

            // prezzo acquisto €/kg
            $table->decimal('price_per_kg',10,2);

            $table->timestamps();

        });

    }


    public function down()
    {

        Schema::dropIfExists('purchase_lots');

    }

};