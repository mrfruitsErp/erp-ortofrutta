<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{

    public function up()
    {
        Schema::create('suppliers', function (Blueprint $table) {

            $table->id();

            $table->string('company_name');

            $table->string('vat_number')->nullable();

            $table->string('phone')->nullable();

            $table->string('email')->nullable();

            $table->string('city')->nullable();

            $table->timestamps();

        });
    }

    public function down()
    {
        Schema::dropIfExists('suppliers');
    }

};