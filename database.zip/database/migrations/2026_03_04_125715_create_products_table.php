<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('products', function (Blueprint $table) {

        $table->id();

        $table->string('name');

        $table->decimal('price',10,2)->default(0);

        $table->decimal('cost',10,2)->default(0);

        $table->decimal('stock',10,2)->default(0);

        $table->string('unit')->default('kg');

        $table->timestamps();

    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};