<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up()
    {
        // Colonna già esistente, migration disattivata
    }

    public function down()
    {
        //
    }
};