<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\DocumentController;


/*
|--------------------------------------------------------------------------
| HOME
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return redirect('/dashboard');
});


/*
|--------------------------------------------------------------------------
| DASHBOARD
|--------------------------------------------------------------------------
*/

Route::get('/dashboard', function () {
    return "Dashboard OK";
});

/*
|--------------------------------------------------------------------------
| ERP ROUTES
|--------------------------------------------------------------------------
*/

Route::middleware(['auth'])->group(function () {

    /*
    |--------------------------------------------------------------------------
    | CLIENTI
    |--------------------------------------------------------------------------
    */

    Route::resource('clients', ClientController::class);


    /*
    |--------------------------------------------------------------------------
    | PRODOTTI
    |--------------------------------------------------------------------------
    */

    Route::resource('products', ProductController::class);


    /*
    |--------------------------------------------------------------------------
    | DOCUMENTI
    |--------------------------------------------------------------------------
    */

    Route::resource('documents', DocumentController::class);


    /*
    |--------------------------------------------------------------------------
    | SALVA PESO REALE CASSE
    |--------------------------------------------------------------------------
    */

    Route::post('/save-real-weight', [DocumentController::class,'saveRealWeight'])
    ->name('save.real.weight');

});


/*
|--------------------------------------------------------------------------
| AUTH (Laravel Breeze)
|--------------------------------------------------------------------------
*/

require __DIR__.'/auth.php';